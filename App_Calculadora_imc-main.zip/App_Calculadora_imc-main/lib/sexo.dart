enum Sexo{
  feminino,
  masculino,
}
